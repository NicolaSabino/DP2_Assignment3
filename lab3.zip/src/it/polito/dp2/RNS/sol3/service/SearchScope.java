package it.polito.dp2.RNS.sol3.service;

public enum SearchScope {
	ALL,
	GATES,
	PARKINGAREAS,
	ROADSEGMENTS;
}